<?php

/* 
 * We need an empty functions.php to simulate a valid theme
 * 
 */

