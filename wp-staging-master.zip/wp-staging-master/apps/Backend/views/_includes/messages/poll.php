<div class="wpstg_poll update-nag" style="box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);">
    <p>
        Great, You are using <strong>WP Staging</strong> for a while.
        Hope you are happy with it.

        <br><br>

        Are you interested in copying changes from WPStaging staging site back to your live site?

        <br><br>

        Click on the <a href="https://docs.google.com/forms/d/e/1FAIpQLScZ-dO5WffV3xObn16LwG05tr1HrADD_8L4wbTxPHqoPssVcg/viewform?c=0&w=1&usp=mail_form_link" target="_blank"><i>Yes, i am interested</i></a>
        Button and fill out the poll!

        <br>

        It only takes one (1) minute of your time - I promise!

        <br><br>

        Cheers,

        <br>

        René
    <ul>
        <li class="float:left">
            <a href="https://docs.google.com/forms/d/e/1FAIpQLScZ-dO5WffV3xObn16LwG05tr1HrADD_8L4wbTxPHqoPssVcg/viewform?c=0&w=1&usp=mail_form_link" class="thankyou button button-primary" target="_new" title="Yes, i am interested" style="color: #ffffff;font-weight: normal;margin-right:10px;float:left;">
                Yes, i am interested
            </a>
        </li>
        <li>
            <a href="javascript:void(0);" data-url="<?php echo admin_url("admin-ajax.php")?>" class="wpstg_hide_poll" title="Close It" style="vertical-align:middle;">
                Do Not Ask Again
            </a>
        </li>
    </ul>
</div>

<script type="text/javascript" src="<?php echo $this->url . "js/wpstg-admin-poll.js"?>"></script>