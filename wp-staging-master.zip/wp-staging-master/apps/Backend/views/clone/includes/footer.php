<div id="wpstg-error-wrapper">
    <div id="wpstg-error-details"></div>
</div>
<div style="clear:both;padding-top:20px;">Something not working? <br>Open a support ticket at <a href="https://wp-staging.com/support" target="_blank" rel="external nofollow">https://wp-staging.com/support</a> and we will resolve it quickly.</div>

