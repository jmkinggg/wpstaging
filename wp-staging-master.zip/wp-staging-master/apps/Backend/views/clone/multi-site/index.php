<span class="wpstg-notice-alert" style="margin-top:20px;">
    <?php echo sprintf(__('WordPress Multisite is not supported! Upgrade to <a href="%s" target="_blank">WP Staging Pro</a>', 'wp-staging'), 'https://wp-staging.com/')?>
</span>